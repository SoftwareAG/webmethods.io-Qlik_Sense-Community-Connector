var flowCliSdk = require("@webmethodsio/cli-sdk")
global.logger = new flowCliSdk.logger();

exports.handler = function (event, context, callback) {
  eraseReservedKeys();
  context.callbackWaitsForEmptyEventLoop = false;
  catchUnhandled(callback);
  try {
    switch (event.type) {
      case "action":
        return callAction(event, context, callback);
      case "lookup":
        return callLookup(event, context, callback);
      case "trigger":
        return callTrigger(event, context, callback);
      default:
        return callAuth(event, context, callback);
    }
  } catch (err) {
    callback(err.stack);
  }
};

// Meta support added
function callAuth(event, context, callback) {
  const domain = require('domain').create();
  domain.on('error', console.log.bind(console));

  try {
    var func = require("./authentication");
  } catch (e) {
    return handleError(e, callback);
  }
  var validate = typeof (func.validate) === "function" ?
    func.validate :
    func.test;
  var opt = new flowCliSdk.trigger.Meta(event.meta);

  domain.run(function () {
    validate.call(opt, event.input, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      callback(null, {
        data: data,
        meta: opt.meta,
        logs: logger.getLogs()
      });
    });
  });
}

function callLookup(event, context, callback) {
  var opt = new flowCliSdk.trigger.Meta(event.meta);

  try {
    var func = require(`./${event.type}/${event.func}`);
  } catch (e) {
    return handleError(e, callback);
  }

  var executeContext = Object.assign(func, { setMeta: opt.setMeta.bind(opt) });

  func.execute.call(executeContext, event.input, event.options, function (err, data) {
    if (err) {
      return handleError(err, callback);
    }
    callback(null, {
      data: data,
      meta: opt.meta,
      logs: logger.getLogs()
    });
  });
}

function callAction(event, context, callback) {
  context = event.context ? event.context : {};
  try {
    if (!/^v/.test(event.version)) {
      var func = require(`./${event.type}/${event.func}`);
    } else {
      var func = require(`./${event.type}/${event.version}/${event.func}`)
    }
  } catch (e) {
    return handleError(e, callback);
  }
  func.execute.call(context, event.input, function (err, data) {
    if (err) {
      return handleError(err, callback);
    }
    callback(null, {
      data: data,
      logs: logger.getLogs()
    });
  });
}

function callTrigger(event, context, callback) {
  var opt = new flowCliSdk.trigger.Meta(event.meta);
  try {
    if (!/^v/.test(event.version)) {
      var func = require(`./${event.type}/${event.func}`);
    } else {
      var func = require(`./${event.type}/${event.version}/${event.func}`)
    }
  } catch (e) {
    return handleError(e, callback);
  }

  if (event.triggerType === "activate") {
    func.activate(event.input, opt, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      flowCliSdk.trigger.filter(event.input.customFilters, data, function (err, out) {
        callback(err, {
          data: out,
          meta: opt.meta,
          logs: logger.getLogs()
        });
      });
    });
  } else if (event.triggerType === "validate") {
    func.validate(event.input, opt, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      flowCliSdk.trigger.filter(event.input.customFilters, data, function (err, out) {
        callback(err, {
          data: out,
          meta: opt.meta,
          logs: logger.getLogs()
        });
      });
    });
  } else if (event.triggerType === "execute") {
    const clonedOptions = event.input.polling ? opt : Object.assign(opt, {
      setMeta: opt.setMeta
    });
    const executeContext = Object.assign(func, clonedOptions);
    const executeFn = event.input.polling ? func.execute.bind(func) : func.execute.bind(executeContext);
    // opt = event.input.polling ? opt : event.payload;
    executeFn(event.input, event.input.polling ? clonedOptions : event.payload, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      flowCliSdk.trigger.filter(event.input.customFilters, data, function (err, out) {
        callback(err, {
          data: out,
          meta: executeContext.meta || {},
          logs: logger.getLogs()
        });
      });
    });
  } else if (event.triggerType === "register") {
    const context = Object.assign(func, opt, {
      setMeta: opt.setMeta
    });
    func.register.call(context, event.input, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      callback(err, {
        data: data,
        meta: context.meta || {},
        logs: logger.getLogs()
      });
    });
  } else if (event.triggerType === "unregister") {
    func.unregister(event.input, opt, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      callback(err, {
        data: data,
        meta: opt.meta,
        logs: logger.getLogs()
      });
    });
  } else if (event.triggerType === "userdata") {
    if (typeof func.getUserData !== "function") {
      return callback(null, func.mock_data);
    }
    func.getUserData(event.input, opt, function (err, data) {
      if (err) {
        return handleError(err, callback);
      }
      callback(err, {
        data: data,
        logs: logger.getLogs()
      });
    });
  } else if (event.triggerType === "update") {
    if (typeof func.update !== 'function') {
      return callback(JSON.stringify({
        code: 'FUNCTION_NOT_FOUND'
      }));
    }
    func.update(event.input, function (err, data) {
      if (err) return handleError(err, callback);

      let result = Array.isArray(data) ? data.length ? data[0] : event.input.hook_response : data;
      return callback(null, {
        data: result,
        meta: opt.meta,
        logs: logger.getLogs()
      });
    });
  } else {
    return callback(JSON.stringify({
      code: 'FUNCTION_NOT_FOUND'
    }));
  }
}

function catchUnhandled(callback) {
  process.on("uncaughtException", (err) => {
    callback(err.stack || err);
  });

  process.on("unhandledRejection", (err) => {
    callback(err.stack || err);
  });
}

function handleError(err, callback) {
  err = err && err.stack ? err.stack : typeof err === "object" ? JSON.stringify(err) : err;
  //let log = logger.getLogs().join(";");
  err = String(err);
  return callback(err);
}

function eraseReservedKeys() {
  for (var prop in process.env) {
    if (prop.indexOf('AWS') > -1 || ~prop.indexOf('TRACE_ID')) {
      delete process.env[prop];
    }
  }
}
